//Variables y constantes

let firstname = "Raul";

firstname = "Eduardo";
const lastName= "Garza";

const condition = true;

if(condition){
    const lastname = "GG";
    console.log(lastname);
}

console.log("hola mundo " + firstname + ' ' + lastName);

//template strings
console.log(`Hola Mundo!!! 
${firstname} - ${lastName}`);
